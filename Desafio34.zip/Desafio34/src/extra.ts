declare module Express {
    export interface Session {
      returnTo: string;
    }
  }