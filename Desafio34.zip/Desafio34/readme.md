--------------------------Desafio 34------------------------------
Formato: link a un repositorio en Github con el proyecto cargado. 
Sugerencia: no incluir los node_modules

>> Consigna:
Implementar nuestro proyecto Backend de trabajo en AWS Elastic Beanstalk, realizando todos los cambios necesarios para su despliegue exitoso en dicha plataforma.
Guardar cada producto al ser ingresado, dentro de una tabla de DynamoDB en AWS.
Emitir un email por cada ingreso, mediante el servidor SNS de Amazon, que contenga la información completa del producto.
Incluir toda la estructura y configuración necesaria en nuestro servidor para que estas funciones se realicen de manera correcta.